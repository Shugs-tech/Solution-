function showsidebar(){
    const sidebar = document.querySelector('.sidebar');
    if (sidebar.style.display === 'none'){
     sidebar.style.display = 'flex';
    } else{
     sidebar.style.display = 'none';
    }
}

function hideSidebar(){
    const sidebar = document.querySelector('.sidebar');
    if (sidebar.style.display === 'flex'){
     sidebar.style.display = 'none';
    } else{
        sidebar.style.display = 'flex';
    }
}